package controller;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import service.NoticeService;
import service.NoticeServiceImpl;
import vo.NoticeVO;

@WebServlet("*.do")
public class NoticeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	NoticeService ns = new NoticeServiceImpl();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		System.out.println("MemberController GET 요청");
		
		String requestURI = req.getRequestURI();	
		String contextPath = req.getContextPath();	
		String command = requestURI.substring(contextPath.length());
		System.out.println("요청 : " + command);
		String nextPage = null;
		
		if(command.equals("/notice.do")) {
			ArrayList<NoticeVO> noticeList = ns.noticeAllList();
            req.setAttribute("noticeList",noticeList);
			nextPage = "/board/notice/notice_list.jsp";
			
		}
		
		if(command.equals("/noticeWriteForm.do")) {	
			nextPage = "/board/notice/notice_write.jsp";
		
			
		}
		if(command.equals("/noticeUpdateForm.do")) {	
			NoticeVO notice = ns.noticeDetail(req);
			req.setAttribute("notice",notice);
			
			nextPage = "/board/notice/notice_update.jsp";
		}
		

		
		
		
		if(command.equals("/noticeDetail.do")) {	
			NoticeVO notice = ns.noticeDetail(req);
				req.setAttribute("notice",notice);
			nextPage = "/board/notice/notice_detail.jsp";
		}
		

		boolean isSuccess = false;

		// 요청 처리 성공시 보여줄 화면
		String suc = "/board/notice/notice_success.jsp";
		// 요청 처리 실패 시 보여줄 화면
		String fail = "/board/notice/notice_fail.jsp";
		
		if(nextPage != null) {
			RequestDispatcher rd = req.getRequestDispatcher(nextPage);
			rd.forward(req, resp);
		}
		
	} // end doGEt
	
	
	// -----------------------------------------------------------------------
	

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String requestURI = req.getRequestURI();	
		String contextPath = req.getContextPath();	
		String command = requestURI.substring(contextPath.length());
		System.out.println("요청 : " + command);
		String nextPage = null;
		
		boolean isSuccess = false;

		// 요청 처리 성공시 보여줄 화면
		String suc = "/board/notice/notice_success.jsp";
		// 요청 처리 실패 시 보여줄 화면
		String fail = "/board/notice/notice_fail.jsp";
		
		if(command.equals("/noticeWrite.do")) {	
			boolean writeTF = false;
			writeTF = ns.noticeWrite(req);
			if(writeTF) {
				nextPage = suc;
			}else {
				nextPage = fail;
			}
		}
		
		if(command.equals("/noticeUpdate.do")) {	
			boolean writeTF = false;
			writeTF = ns.noticeUpdate(req);
			if(writeTF) {
				nextPage = suc;
			}else {
				nextPage = fail;
			}
		}
		
		
		if(nextPage != null) {
			RequestDispatcher rd = req.getRequestDispatcher(nextPage);
			rd.forward(req, resp);
		}
		
	}
}
