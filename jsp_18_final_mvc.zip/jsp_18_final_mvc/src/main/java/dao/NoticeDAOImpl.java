package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.PageMaker;
import vo.NoticeVO;

public class NoticeDAOImpl implements NoticeDAO {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	public void setConnection() {
		try {
			// DriverClass load
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/digital_jsp", "digital", "1234");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void close() {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	} // end close

	@Override
	public ArrayList<NoticeVO> getAllList() {
		ArrayList<NoticeVO> nList = new ArrayList<NoticeVO>();
		try {
			setConnection();
			String sql = "SELECT * FROM notice_board";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeVO n = new NoticeVO();
				n.setNotice_num(rs.getInt("notice_num"));
				n.setNotice_category(rs.getString("notice_category"));
				n.setNotice_author(rs.getString("notice_author"));
				n.setNotice_title(rs.getString("notice_title"));
				n.setNotice_content(rs.getString("notice_content"));
				n.setNotice_date(rs.getDate("notice_date"));
				nList.add(n);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nList;
	}

	@Override
	public boolean noticeWrite(NoticeVO noticeVO) {
		try {
			setConnection();
			String sql = "INSERT INTO notice_board(notice_category,notice_author,notice_title,notice_content,notice_date) VALUES(?,?,?,?,now())";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, noticeVO.getNotice_category());
			pstmt.setString(2, noticeVO.getNotice_author());
			pstmt.setString(3, noticeVO.getNotice_title());
			pstmt.setString(4, noticeVO.getNotice_content());
			int rs = pstmt.executeUpdate();
			if (rs != 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public NoticeVO getNoticeVO(int notice_num) {
		try {
			setConnection();
			String sql = "SELECT * FROM notice_board where notice_num = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_num);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeVO n = new NoticeVO();
				n.setNotice_num(rs.getInt("notice_num"));
				n.setNotice_category(rs.getString("notice_category"));
				n.setNotice_author(rs.getString("notice_author"));
				n.setNotice_title(rs.getString("notice_title"));
				n.setNotice_content(rs.getString("notice_content"));
				n.setNotice_date(rs.getDate("notice_date"));
				return n;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean noticeUpdate(NoticeVO noticeVO) {
			try {
				setConnection();
				String sql = "UPDATE notice_board SET notice_num = ?, notice_num= ?, notice_num= ?, notice_num= ?, "
						   + " WHERE notice_num = ? ";
				PreparedStatement pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, noticeVO.getNotice_category());
				pstmt.setString(2, noticeVO.getNotice_author());
				pstmt.setString(3, noticeVO.getNotice_title());
				pstmt.setString(4, noticeVO.getNotice_content());
				pstmt.setInt(4, noticeVO.getNotice_num());
				
				int rs = 	pstmt.executeUpdate();
				if(rs!=0){
					return true;
				}else {
					return false;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}

	@Override
	public boolean noticeDelete(int notice_num) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<NoticeVO> getNoticeList(int startRow, int perPageNum) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getListCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getSearchListCount(String searchName, String searchValue) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<NoticeVO> getSearchNoticeList(PageMaker pageMaker) {
		// TODO Auto-generated method stub
		return null;
	}

}
