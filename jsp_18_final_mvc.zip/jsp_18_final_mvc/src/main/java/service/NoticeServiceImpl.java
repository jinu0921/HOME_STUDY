package service;

import java.util.ArrayList;

import dao.NoticeDAO;
import dao.NoticeDAOImpl;
import jakarta.servlet.http.HttpServletRequest;
import vo.NoticeVO;

public class NoticeServiceImpl implements NoticeService{
		
	NoticeDAO dao = new NoticeDAOImpl();
	
	ArrayList<NoticeVO> noticeList = dao.getAllList();
	@Override
	
	// 클리어
	
	public ArrayList<NoticeVO> noticeAllList() {
		return dao.getAllList();
	}
	

	@Override
	public boolean noticeWrite(HttpServletRequest request) {
		NoticeVO nv = new NoticeVO();
		nv.setNotice_author(request.getParameter("notice_author"));
		nv.setNotice_title(request.getParameter("notice_title"));
		nv.setNotice_category(request.getParameter("notice_category"));
		nv.setNotice_content(request.getParameter("notice_content"));	
		
		
		return dao.noticeWrite(nv);
	}

	@Override
	public ArrayList<NoticeVO> noticeList(HttpServletRequest request) {
		
		return null;
	}

	
	// 클리어
	
	@Override
	public NoticeVO noticeDetail(HttpServletRequest request) {
		return dao.getNoticeVO(Integer.parseInt(request.getParameter("notice_num")));
	}

	@Override
	public boolean noticeUpdate(HttpServletRequest request) {
		NoticeVO nv = new NoticeVO();
		nv.setNotice_author(request.getParameter("notice_author"));
		nv.setNotice_title(request.getParameter("notice_title"));
		nv.setNotice_category(request.getParameter("notice_category"));
		nv.setNotice_content(request.getParameter("notice_content"));	
		
		
		nv.setNotice_num(Integer.parseInt(request.getParameter("notice_num")));
		
		
		return dao.noticeUpdate(nv);
	}

	@Override
	public boolean noticeDelete(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<NoticeVO> search(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

}
